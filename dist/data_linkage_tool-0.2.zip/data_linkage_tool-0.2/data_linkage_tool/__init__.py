import pandas as pd

def helloProject():
	print pd.date_range('20130101', periods=6)
	print "Hello python"