from setuptools import setup

setup(name='data_linkage_tool',
      version='0.3',
      description='Do python project',
      url='http://github.com/pythonPro/data_linkage_tool',
      author='Tung PT',
      author_email='thanhtungit92@gmail.com',
      license='MIT',
      packages=['data_linkage_tool'],
      install_requires=[
          'pandas',
      ],
      zip_safe=False)