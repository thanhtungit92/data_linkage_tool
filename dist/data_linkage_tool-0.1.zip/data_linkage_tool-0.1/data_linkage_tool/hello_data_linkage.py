def helloProject():
	print "Hello python"